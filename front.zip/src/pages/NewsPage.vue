<script>
export default {
  name: 'NewsPage',
}
</script>

<template>
  NewsPage
</template>

<style scoped>

</style>
