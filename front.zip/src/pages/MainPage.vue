<script>
export default {
  name: 'MainPage',
}
</script>

<template>
MainPage
</template>

<style scoped>

</style>
