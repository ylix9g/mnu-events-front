<script>
import EventList from '@/components/EventList.vue'

export default {
  name: 'EventsPage',
  components: { EventList },
}
</script>

<template>
  <EventList/>
</template>

<style scoped>

</style>
